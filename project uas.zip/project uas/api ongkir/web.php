<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\CheckoutController;
use Inertia\Inertia;


Route::middleware('auth')->group(function () {
    Route::get('/checkout','CheckoutController@checkout');
    Route::get('/kota/{id}','CheckoutController@get_city');
    Route::get('/province','CheckoutController@get_province');
    Route::get('/origin={city_origin}&destination={city_destination}&weight={weight}&courier={courier}','CheckoutController@get_ongkir');
    });
require __DIR__ . '/auth.php';
