<?php


use App\Http\Controllers\Auth\CheckoutController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth')->group(function () {
Route::get('/checkout','CheckoutController@checkout');
Route::get('/kota/{id}','CheckoutController@get_city');
Route::get('/province','CheckoutController@get_province');
Route::get('/origin={city_origin}&destination={city_destination}&weight={weight}&courier={courier}','CheckoutController@get_ongkir');
});